describe file('c:/windows/fonts/CodeNewRoman.otf') do
  it { should exist }
end

describe file('c:/windows/fonts/Asimov.otf') do
  it { should exist }
end
