name             "hpcpack"
maintainer       "Cycle Computing, LLC"
maintainer_email "cyclecloud-support@cyclecomputing.com"
license          "All rights reserved"
description      "HPCPack scheduler"
version          "0.1"

depends 'windows'
