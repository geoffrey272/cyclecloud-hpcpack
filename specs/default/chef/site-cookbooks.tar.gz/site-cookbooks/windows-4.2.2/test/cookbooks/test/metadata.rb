name 'test'
version '0.0.1'
depends 'windows'
